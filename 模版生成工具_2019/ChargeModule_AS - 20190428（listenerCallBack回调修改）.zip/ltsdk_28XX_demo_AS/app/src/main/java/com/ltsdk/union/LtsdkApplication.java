
package com.ltsdk.union;

import android.app.Application;



public class LtsdkApplication extends Application
{
    // public static Application Instance;
    //
    public void onCreate()
    {
        super.onCreate();
        // Instance = this;

        CrashHandler handler = CrashHandler.getInstance();
        handler.init(getApplicationContext());
    }

    // private static String APPKEY = "2078010500";
    // private static String APPSECRET = "t1l45hu449p022c76a7iey5f95s88688";
    //
    // @Override
    // public void onCreate()
    // {
    // // 获取配置参数
    // APPKEY = PropertyUtil.getConfig(this, "APPKEY", APPKEY).trim();
    // APPSECRET = PropertyUtil.getConfig(this, "APPSECRET", APPSECRET).trim();
    //
    // // 获取横竖屏属性
    // int orientation = Tools.isLandscape(this) ? ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE : ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;
    //
    // // ActivityInfo.SCREEN_ORIENTATION_PORTRAIT 竖屏
    // // ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE 横屏
    // HiGameSDK.getInstance().init(this, new HiGameSettings(APPKEY, APPSECRET, orientation));
    //
    // // 调试时打开，正式发布版本的时候需要去掉
    // // HiGameSDK.getInstance().setDebug(true);
    // CrashHandler.getInstance().init(this);
    // }
}
