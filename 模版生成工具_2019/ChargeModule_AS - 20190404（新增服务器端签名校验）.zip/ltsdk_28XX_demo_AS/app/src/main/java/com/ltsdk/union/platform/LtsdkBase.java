package com.ltsdk.union.platform;

import java.util.HashMap;
import java.util.Map;

import android.content.Intent;
import android.content.res.Configuration;

import com.ltsdk.union.LtsdkKey;

//import android.util.Log;
//
//import com.ltsdk.union.util.PropertyUtil;
//import com.nearme.game.sdk.GameCenterSDK;
//import com.nearme.game.sdk.callback.ApiCallback;
//import com.nearme.game.sdk.callback.GameExitCallback;
//import com.nearme.game.sdk.common.model.ApiResult;
//import com.nearme.game.sdk.common.model.biz.PayInfo;
//import com.nearme.game.sdk.common.model.biz.ReportUserGameInfoParam;
//import com.nearme.platform.opensdk.pay.PayResponse;


/** LtsdkBase.java: ----- 2017-5-27 10:50:51 wangzhongyuan */
public class LtsdkBase extends BaseFunction
{
//	private String oppo_appid = "";

    /* 初始化 */
    public void _Init()
    {
//		oppo_appid = PropertyUtil.getConfig(getAppContext(), "oppo_appid", "");
//
//		String appSecret = PropertyUtil.getConfig(activity, "oppo_appsecret", "");
//		GameCenterSDK.init(appSecret, activity);

        this.initSuccess();	// 通知游戏初始化成功
    }

    /* 渠道登录 */
    public void _PlatformLogin()
    {
//		GameCenterSDK.getInstance().doLogin(activity, new ApiCallback()
//		{
//			@Override
//			public void onSuccess(String resultMsg)
//			{
//				doGetTokenAndSsoid();						// 登录渠道后，获取相关参数信息
//
//				LtsdkBase.this.Platform_loginSuccess();		// 渠道登录成功
//			}
//
//			@Override
//			public void onFailure(String resultMsg, int resultCode)
//			{
//				LtsdkBase.this.Platform_loginFail();		// 渠道登录失败
//				Tools.showText("渠道登录失败，" + " resultCode:" + resultCode + " resultMsg:" + resultMsg);
//			}
//		});
    }

    // 渠道登录后，获取的参数信息
    public void doGetTokenAndSsoid()
    {
//		GameCenterSDK.getInstance().doGetTokenAndSsoid(new ApiCallback()
//		{
//			@Override
//			public void onSuccess(String resultMsg)
//			{
//				String mToken = Tools.getJsonValue(resultMsg, "token");
//				String mSsoid = Tools.getJsonValue(resultMsg, "ssoid");
//
//				// 添加乐堂登录参数
//				AddLoginParams("version", "2");
//				AddLoginParams("app_id", oppo_appid);
//				AddLoginParams("token", mToken);
//				AddLoginParams("ssoid", mSsoid);
//
//				// doGetUserInfoByCpClient(token, ssoid);
//				Tools.showText("渠道登录后，获取参数信息:\r\n" + " resultMsg:" + resultMsg);
//			}
//
//			@Override
//			public void onFailure(String content, int resultCode)
//			{
//				Tools.showText("渠道登录后，获取Token信息失败！\r\n" + " resultCode:" + resultCode + " content:" + content);
//			}
//		});
    }

    /* 渠道支付 */
    public void _PlatformPay()
    {
        SdkInfo info = new SdkInfo(this); 	// 获取sdk中的参数信息

//		PayInfo payInfo = new PayInfo(LtOrderId, oppo_appid + "_" + LtOrderId, info.MoneyAmount_IntFen);
//		payInfo.setProductDesc(info.ProductDescript);
//		payInfo.setProductName(info.ProductName);
//		payInfo.setCallbackUrl(LTSDK_CALLBACK_URL);
//
//		// 调用渠道支付
//		GameCenterSDK.getInstance().doPay(getActivity(), payInfo, new ApiCallback()
//		{
//			@Override
//			public void onSuccess(String resultMsg)
//			{
//				LtsdkBase.this.paySuccess();		// 支付成功
//			}
//
//			@Override
//			public void onFailure(String resultMsg, int resultCode)
//			{
//				if (PayResponse.CODE_CANCEL != resultCode)
//				{
//					LtsdkBase.this.payFail();		// 支付失败
//					Tools.showText("支付失败" + ", resultCode:" + resultCode + ", resultMsg:" + resultMsg);
//				}
//				else
//				{
//					LtsdkBase.this.payCancel();		// 支付取消
//				}
//			}
//		});
    }

    /** 渠道退出逻辑 */
//	public void _Quit()
//	{
//		GameCenterSDK.getInstance().onExit(activity, new GameExitCallback()
//		{
//			@Override
//			public void exitGame()
//			{
//				LtsdkBase.this.quitSuccess();	// 退出成功
//			}
//		});
//	}

    /** 显示悬浮框 */
    public void _ShowToolbar()
    {
//		GameCenterSDK.getInstance().onResume(activity);
    }

    /** 隐藏悬浮框 */
    public void _HideToolbar()
    {
//		GameCenterSDK.getInstance().onPause();
    }

    /** 暂停游戏 */
    public void _OnPause()
    {}

    /** 继续游戏 */
    public void _OnResume()
    {
        _ShowToolbar();
    }

    /** 停止运行 */
    public void _OnStop()
    {
        _HideToolbar();
    }

    /** Destroy */
    public void _OnDestroy()
    {}

    /** 开始 */
    public void onStart()
    {}

    public void onRestart()
    {}

    public void onNewIntent(Intent intent)
    {}

    /** activityResult */
    public void onActivityResult(int requestCode, int resultCode, Intent data)
    {}

    public void onConfigurationChanged(Configuration newConfig)
    {}


    /** 渠道上传游戏角色信息 */
    public void _UploadUserInfo()
    {
        //SdkInfo info = new SdkInfo(this); 	// 获取sdk中的参数信息
    }

    /** 渠道上传游戏角色信息示例 */
    public void _UploadExample()
    {
        Map<String, String> map = new HashMap<String, String>();

        map.put(LtsdkKey.LtInstantId, "8001");							// 服务器id
        map.put(LtsdkKey.RoleName, "角色名称");							// 角色名称
        map.put(LtsdkKey.RoleLevel, "1");								// 角色等级

        setCommon(map);		// 调用接口上传游戏数据信息
    }

}
