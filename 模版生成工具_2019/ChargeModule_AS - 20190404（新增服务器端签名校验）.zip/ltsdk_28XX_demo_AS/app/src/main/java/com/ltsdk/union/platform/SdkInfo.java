
package com.ltsdk.union.platform;

import java.text.DecimalFormat;
import java.util.Map;

import com.ltsdk.union.LtsdkKey;


/** SdkInfo.java: ----- 2017-5-10 上午11:14:00 wangzhongyuan */
public class SdkInfo
{
    public String ServerId = "", SeverName = "", ServerIndex = "", MoneyAmount_Str = "", MoneyAmount_FloatStr = "", MoneyAmount = "", ProductId = "",
            ProductName = "", ProductDescript = "", RoleId = "", RoleName = "", Balance = "", RoleLevel = "", RoleVipLevel = "", RolePartyId = "",
            RoleCTime = "", RoleCTimeSecond = "", RolePartyName = "", PartyName = "", PartyId = "", Profession = "", ProfessionId = "", Friendlist = "",
            RoleFighting = "", AppId = "", SceneType = "", gender = "";
    public float MoneyAmount_Float = 0, BalanceFloat = 0;
    public double MoneyAmount_Double = 0;
    public int MoneyAmount_Int = 0, MoneyAmount_IntFen = 0;

    public SdkInfo(LtsdkAdapter sdk)
    {
        Tools.showText("SdkInfo() -> 获取sdk中的参数信息");

        try
        {
            Map<String, String> sdkInfo = sdk.getLtsdkInfo();

            ServerId = Tools.CheckStr(sdkInfo.get(LtsdkKey.LtInstantId), "001", "LtInstantId:服务器id");		// 服务器id
            SeverName = Tools.CheckStr(sdkInfo.get(LtsdkKey.LtInstantAlias), "LtInstantAlias:服务器名");		// 服务器名
            ServerIndex = Tools.CheckStr(sdkInfo.get(LtsdkKey.LtInstantIndex), "1", "LtInstantIndex:服务器序号，从1开始的连续数");		// 服务器序号

            ProductId = Tools.CheckStr(sdkInfo.get(LtsdkKey.ProductId), "ProductId:商品Id");					// 商品Id
            if(ProductId.equals("0")) ProductId = "00";
            ProductName = Tools.CheckStr(sdkInfo.get(LtsdkKey.ProductName), "ProductName:商品名称");			// 商品名称
            ProductDescript = Tools.CheckStr(sdkInfo.get(LtsdkKey.ProductDescript), "0", "商品描述");			// 商品描述

            MoneyAmount_Str = Tools.CheckStr(sdkInfo.get(LtsdkKey.MoneyAmount), "1", "商品单价");				// 商品单价原有信息串
            MoneyAmount_IntFen = Tools.ToInt(sdkInfo.get(LtsdkKey.MoneyAmount), 1, "商品单价");				// 商品单价:Int型（以分为单位的）
            MoneyAmount_Float = Float.parseFloat(MoneyAmount_Str) / 100;									// 商品单价:float型
            MoneyAmount_Double = Integer.parseInt(MoneyAmount_Str) / 100.00;								// 商品单价:double型
            DecimalFormat fnum = new DecimalFormat("##0.00");
            MoneyAmount_FloatStr = fnum.format(MoneyAmount_Float);											// 商品单价:float字符串型（如0.01元）
            MoneyAmount_Int = (int) Math.ceil(MoneyAmount_Float);											// 商品单价:Int型
            MoneyAmount = MoneyAmount_Int + "";																// 商品单价(Int型->字符串)

            RoleId = Tools.CheckStr(sdkInfo.get(LtsdkKey.RoleId), "RoleId:角色Id");							// 角色Id
            RoleName = Tools.CheckStr(sdkInfo.get(LtsdkKey.RoleName), "RoleName:角色名");					// 角色名
            Balance = Tools.CheckStr(sdkInfo.get(LtsdkKey.RoleBalance), "0", "RoleBalance:用户余额");			// 用户余额
            BalanceFloat = Tools.ToFloat(sdkInfo.get(LtsdkKey.RoleBalance), 0, "RoleBalance:用户余额");		// 用户余额:float型
            RoleLevel = Tools.ToInt(sdkInfo.get(LtsdkKey.RoleLevel), 0, "RoleLevel:角色等级") + "";			// 角色等级
            RoleVipLevel = Tools.ToInt(sdkInfo.get(LtsdkKey.RoleVipLevel), 0, "RoleVipLevel:角色vip等级") + "";	// 角色vip等级
            RolePartyId = Tools.CheckStr(sdkInfo.get(LtsdkKey.RolePartyId), "RolePartyId:角色帮派id");		// 角色帮派id
            RoleCTime = Tools.ToLong(sdkInfo.get(LtsdkKey.roleCTime), Tools.DefaultDateMillions, "roleCTime:角色创建时间") + "";					// 角色创建时间(毫秒）
            RoleCTimeSecond = (Tools.ToLong(sdkInfo.get(LtsdkKey.roleCTime), Tools.DefaultDateMillions, "roleCTime:角色创建时间") / 1000) + "";	// 角色创建时间(秒）
            RolePartyName = Tools.CheckStr(sdkInfo.get(LtsdkKey.RolePartyName), "用户所属帮派名称", "RolePartyName:用户所属帮派名称"); 		// 用户所属帮派名称
            PartyName = Tools.CheckStr(sdkInfo.get(LtsdkKey.partyName), "帮派名称", "partyName:帮派名称");		// 帮派名称
            PartyId = Tools.CheckStr(sdkInfo.get(LtsdkKey.partyId), "帮派id", "partyName:帮派id");			// 帮派id
            Profession = Tools.CheckStr(sdkInfo.get(LtsdkKey.profession), "职业", "profession:职业");			// 职业
            ProfessionId = Tools.CheckStr(sdkInfo.get(LtsdkKey.professionId), "职业id", "professionId:职业id");			// 职业id
            Friendlist = Tools.CheckStr(sdkInfo.get(LtsdkKey.friendlist), "", "friendlist:好友列表");			// 好友列表
            RoleFighting = Tools.CheckStr(sdkInfo.get(LtsdkKey.RoleFighting), "角色战力", "RoleFighting:角色战力");		// 角色战力
            AppId = Tools.CheckStr(sdkInfo.get(LtsdkKey.LtAppId), "10001", "LtAppId:乐堂应用id");				// 乐堂应用id

            String tipInfo = "sceneType: 上传角色数据场景类型,不可为 空或null,\r\n登录、升级、创建角色、退出 传入参数依次为： \"enterServer\"、\"levelUp\"、\"createRole\"、\"exitServer\"";
            SceneType = Tools.CheckStr(sdkInfo.get(LtsdkKey.sceneType), LtsdkKey.SCENETYPE_360.enterServer, tipInfo);	// 场景类型
            gender = Tools.CheckStr(sdkInfo.get(LtsdkKey.gender), "男", "gender:用户性别");					// 性别
        }
        catch (Exception e)
        {
            Tools.showText("SdkInfo() -> 获取sdk中的参数信息异常！" + "\r\n" + e.toString());
            e.printStackTrace();
        }

    }
}
