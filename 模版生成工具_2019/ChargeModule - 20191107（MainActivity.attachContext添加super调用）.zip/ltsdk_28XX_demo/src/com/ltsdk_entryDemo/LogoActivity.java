﻿
package com.ltsdk_entryDemo;

import com.ltsdk.union.LogoCallBack;
import com.ltsdk.union.Ltsdk;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.RelativeLayout;

// 游戏启动界面，先展示logo,后跳转MainActivity
public class LogoActivity extends Activity
{
	private Activity mActivity;
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		mActivity = this;
		
		// *** 加载封面Logo （必接）***
		// 1. 执行后，程序会先回调showLogo()方法，等过3秒（可设置）后，会调用endLogo()方法。
		// 2. 开发者得到Logo的图片资源ID和背景颜色ID后，可以自行处理封面Logo展示。
		// 3. startLogo()方法和init()方法是互不影响的方法，所以调用startLogo()展示封面的时候不用事先初始化。
		// 4. Logo的展示时间、图片资源和背景颜色可以在配置文件（assets/ltsdk_res/config.txt）中设置。
		Ltsdk.getInstance().startLogo(mActivity, logoCallback, "0");
	}
	
	/** 示例：Logo封面显示和关闭回调 */
	private LogoCallBack logoCallback = new LogoCallBack()
	{
		@Override
		public void showLogo(int imgId, int bgColor)
		{
			// 示例：显示Logo封面
			ImageView logo = new ImageView(mActivity);
			logo.setImageResource(imgId);
			logo.setClickable(true);
			logo.setScaleType(ScaleType.CENTER_INSIDE);
			RelativeLayout layout = new RelativeLayout(mActivity);
			layout.setBackgroundColor(bgColor);
			RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
			layoutParams.addRule(RelativeLayout.CENTER_IN_PARENT);
			layout.addView(logo, layoutParams);
			mActivity.addContentView(layout, new RelativeLayout.LayoutParams(-1, -1));
		}
		
		@Override
		public void endLogo()
		{
			// 示例：跳转到主页面
			Intent intent = new Intent(mActivity, MainActivity.class);
			mActivity.startActivity(intent);
			mActivity.finish();
		}
	};
}
