﻿
package com.ltsdk_entryDemo;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.ltsdk.union.Ltsdk;
import com.ltsdk.union.LtsdkExtkey;
import com.ltsdk.union.LtsdkKey;
import com.ltsdk.union.LtsdkListener;
import com.ltsdk.union.platform.Tools;
import com.ltsdk_28XX_module.v200.R;


public class MainActivity extends Activity
{
    private static final String TAG = "Ltsdk_MainActivity";
    private Activity mActivity = null;
    private Context mAppContext;

    // 聚合SDK初始化是否成功
    private boolean isInitSuccess = false;

    // 登录成功后获取的用户ID
    private String mLtUserId = "1";
    private ExecutorService mThread;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ltsdk_activity_main);
        mActivity = this;
        mAppContext = mActivity.getApplicationContext();
        mThread = Executors.newSingleThreadExecutor();

        // *** 初始化计费聚合SDK（必接） ***
        // 1. 初始化方法必须在onCreate()方法中调用。
        // 2. 游戏中如果有多个Activity，请在主Activity中初始化聚合SDK。
        // 参数说明：
        // activity 上下文对象
        // listener 登录、支付等结果回调函数
        // isFullScreen 游戏是否为全屏
        // isLandScape 游戏是否横屏显示
        Ltsdk.getInstance().init(mActivity, listener, true, true);

        // 设置计费sdk名称信息
        String sdkName = Tools.getAppName(mActivity);
        TextView text = (TextView)this.findViewById(R.id.ltsdk_version);
        text.setText(sdkName);
    }

    /** 界面按钮点击事件 */
    public void clickHandler(View view)
    {
        switch (view.getId())
        {

            // *** 登陆 （必接）***
            case R.id.lt_login:
                // 初始化是否成功
                if (isInitSuccess)
                {
                    mThread.execute(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            Ltsdk.getInstance().login();
                        }
                    });
                }
                break;

            case R.id.lt_setCommon:
                // *** 登录成功后必须调用此接口，设置基本信息 ***
                // 此处设置的参数为全局参数，如果参数无变化，支付的时候可以不用传递
                mThread.execute(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        Map<String, String> common = getCommonInfo();
                        Ltsdk.getInstance().setCommon(common);
                    }
                });
                break;

            // *** 切换账号 （选接）***
            case R.id.lt_switchAccount:
                // 初始化是否成功
                if (isInitSuccess)
                {
                    mThread.execute(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            Ltsdk.getInstance().switchAccount();
                        }
                    });
                }
                break;

            // *** 退出游戏（必接） ***
            case R.id.lt_quit:
                mThread.execute(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        Ltsdk.getInstance().quit();
                    }
                });
                break;

            // *** 注销用户登录状态（选接） ***
            case R.id.lt_logout:
                mThread.execute(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        Ltsdk.getInstance().logout();
                    }
                });
                break;

            // *** 显示工具条 （选接）***
            case R.id.lt_showToolbar:
                mThread.execute(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        Ltsdk.getInstance().showToolbar();
                    }
                });
                break;

            // *** 隐藏工具条 （选接）***
            case R.id.lt_hideToolbar:
                mThread.execute(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        Ltsdk.getInstance().hideToolbar();
                    }
                });
                break;

            // *** 支付 （必接）***
            case R.id.lt_pay:
                // 获取支付所需配置
                mThread.execute(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        Map<String, String> payInfo = getPayInfo();
                        Ltsdk.getInstance().pay(payInfo);
                    }
                });
                break;

            // *** 拓展接口上传用户角色信息示例***
            case R.id.lt_UploadExample:
                mThread.execute(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        Ltsdk.getInstance().extension("UploadExample", null);
                    }
                });
                break;
			
            // *** 拓展接口 （选接）***
            case R.id.lt_extension:
                // 悠悠村渠道需要调用此接口，需要在游戏中添加一个“设置”按钮，然后调用此接口
                mThread.execute(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        Ltsdk.getInstance().extension(LtsdkExtkey.OPEN_SETTING, null);
                    }
                });
                break;

            // *** 获取配置 ***
            case R.id.lt_getConfig:
                mThread.execute(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        // 示例：获取配置
                        configHandler();
                        printLog(null, "获取配置成功，请查看Log");
                    }
                });
                break;
        }
    }

    /** Ltsdk处理结果回调 */
    private LtsdkListener listener = new LtsdkListener()
    {

        @Override
        public void onCallBack(String data)
        {
            // data为json格式数据
            // 参考格式：{"code":110,"info":"登录成功","data":{"content":{"uid":"3223751","server_id":"0","sex":"0","user_type":1,"channelId":"","uname":"94222136","androidId":"","IMSI":"","score":"0","platform_uid":"a12345678","avatar":"0","screenType":"","operator":"0","country":"","sign":"这家伙很懒，什么都没留下","addtime":"2014-09-17 16:23:41","nname":"94222136","IMEI":"","token":"dce2e380050c89c60d1e95ef45fba378","lasttime":"2014-09-17 16:23:41","platform_type":"letangdemo","money":"0","guest":"1","app_id":"0","language":""},"msg":"登录成功","status":1}}
            try
            {
                JSONObject dataJson = new JSONObject(data);
                // 回调类型，用来判断为何种回调
                int code = dataJson.getInt("code");
                // 回调描述
                String info = dataJson.getString("info");
                // 数据内容，如用户成功登录后返回用户基本信息
                JSONObject dt = dataJson.getJSONObject("data");

                // 打印Log和Toast信息
                printLog(data, info);

                switch (code)
                {

                    // *** 初始化接口回调 ***
                    case LtsdkListener.ACTION_INIT_SUCCESS:
                        // 标记初始化成功，登录时需要判断
                        isInitSuccess = true;

                        // *** 是否自动登录 ***
                        // 读取Ltsdk配置文件中的lt_platformautologin配置
                        String platformAutoLogin = Ltsdk.getInstance().getConfig(mAppContext, "lt_platformautologin", "false");
                        if ("true".equals(platformAutoLogin))
                        {
                            // 调用登录接口登录
                            Ltsdk.getInstance().login();
                        }
                        break;
                    case LtsdkListener.ACTION_INIT_FAIL:
                        break;

                    // *** 登录（切换账户）回调 ***
                    case LtsdkListener.ACTION_LOGIN_SUCCESS:// 登陆（切换账户）成功回调
                        // 登录（切换账户）成功后解析用户数据
                        loginHandler(dt);
                        break;
                    case LtsdkListener.ACTION_LOGIN_FAIL: // 登陆（切换账户）失败回调
                    case LtsdkListener.ACTION_LOGIN_CANCEL: // 登陆（切换账户）取消回调
                        break;

                    // *** 退出接口回调 ***
                    case LtsdkListener.ACTION_QUIT_SUCCESS: // 退出成功回调
                    case LtsdkListener.ACTION_QUIT_FAIL: // 退出失败回调
                    case LtsdkListener.ACTION_QUIT_CANCEL: // 退出取消回调
                        break;
                    case LtsdkListener.ACTION_QUIT_CUSTOM:// 自定义退出
                        // *** 特别提醒 （必接）***
                        // 1.必须实现此自定义退出界面。
                        // 2.用户点击退出按钮后，如果渠道平台没有自己的退出界面，那么会触发此类回调。

                        QuitCustom();
                        break;

                    // *** 支付接口回调 ***
                    // 注意：不是每一个平台都有支付成功或失败的回调
                    case LtsdkListener.ACTION_PAY_SUCCESS: // 支付成功回调
                    case LtsdkListener.ACTION_PAY_FAIL: // 支付失败回调
                    case LtsdkListener.ACTION_PAY_CANCEL: // 支付取消回调
                    case LtsdkListener.ACTION_PAY_NOW: // 支付进行中回调
                        break;

                    // *** 渠道平台切换账户的回调（必接） ***
                    case LtsdkListener.ACTION_PLATFORMACCOUNTSWITCH_SUCCESS:// 渠道平台切换账户成功回调
                        // *** 特别提醒 ***
                        // 1.如果某平台有切换账户的功能且用户点击了平台上的切换账户按钮，那么会触发此切换账户的回调，其他情况下不会触发此类回调。
                        // 2.请注意此回调不是聚合SDK中的切换账户接口所发出的。聚合SDK中的切换账户接口是间接调用了登录接口，所以聚合SDK中的切换账户接口发出的回调是跟登录接口一样。
                        // 3.开发者根据游戏自身情况处理该回调，可以重启游戏，也可注销用户信息后回到登录界面让用户登录。
                        break;
                    case LtsdkListener.ACTION_PLATFORMACCOUNTSWITCH_FAIL:// 渠道平台切换账户失败回调
                    case LtsdkListener.ACTION_PLATFORMACCOUNTSWITCH_CANCEL:// 渠道平台切换账户取消回调
                        break;
                }
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }
    };

    // demo自定义退出逻辑
    private void QuitCustom()
    {
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("确认退出？");
        dialog.setIcon(android.R.drawable.ic_dialog_info);
        dialog.setPositiveButton("确定", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                System.exit(0);		// 退出运行
            }
        });

        dialog.setNegativeButton("取消", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                // 点击“返回”后的操作,这里不设置没有任何操作
            }
        });

        dialog.show();
    }

    protected void onResume()
    {
        super.onResume();

        // *** 调用Ltsdk的resume()方法（必接） ***
        // 特别注意：此方法需要在每个Activity的onResume()方法中调用
        // 如果某些Activity只在聚合SDK初始化之前显示，且初始化之后不会再显示，那么可以不用在此Acitivity中添加resume()接口。
        Ltsdk.getInstance().resume(mActivity);
    }

    @Override
    protected void onPause()
    {
        super.onPause();

        // *** 调用Ltsdk的pause()方法 （必接）***
        // 特别注意：此方法需要在每个Activity的onPause()方法中调用
        // 如果某些Activity只在聚合SDK初始化之前显示，且初始化之后不会再显示，那么可以不用在此Acitivity中添加onPause()接口。
        Ltsdk.getInstance().pause();
    }

    @Override
    protected void onStop()
    {
        super.onStop();

        // *** 调用Ltsdk的stop()方法 （必接）***
        // 部分平台需使用到
        Ltsdk.getInstance().stop();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        // *** 调用Ltsdk的activityResult()方法 （必接）***
        // 部分平台登录后，用户数据通过activityResult返回
        Ltsdk.getInstance().activityResult(requestCode, resultCode, data);
    }

    public void onConfigurationChanged(Configuration newConfig)
    {
        super.onConfigurationChanged(newConfig);

        Ltsdk.getInstance().onConfigurationChanged(newConfig);
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();

        // *** 调用Ltsdk的destroy()方法（必接） ***
        // 用户销毁资源，释放内存
        Ltsdk.getInstance().destroy();
    }

    @Override
    public void onBackPressed()
    {
        // super.onBackPressed();

        // *** 调用Ltsdk的onBackPressed()方法 ***
        // 返回
        Ltsdk.getInstance().onBackPressed();
    }


    public void onRestart()
    {
        super.onRestart();

        Ltsdk.getInstance().restart();
    }

    public void onNewIntent(Intent intent)
    {
        super.onNewIntent(intent);

        Ltsdk.getInstance().newIntent(intent);
    }

    /** 用户登录成功回调 */
    private void loginHandler(JSONObject dt)
    {
        try
        {
            JSONObject content = new JSONObject(dt.getString("content"));
            // 乐堂用户ID
            mLtUserId = content.getString("uid");
            printLog(null, "用户ID：" + mLtUserId);

            // 获得用户类型（防沉迷使用）
            int userType = content.getInt("user_type");
            if (LtsdkListener.USERTYPE_MATURE == userType)
            {
                printLog(null, "成年用户");
            }
            else if (LtsdkListener.USERTYPE_IMMATURE == userType)
            {
                printLog(null, "未成年用户");
            }
            else if (LtsdkListener.USERTYPE_UNKNOWN == userType)
            {
                printLog(null, "未知用户");
            }
        }
        catch (Exception e)
        {}
    }

    /** 获取常用信息 */
    private Map<String, String> getCommonInfo()
    {
        Map<String, String> map = new HashMap<String, String>();
        // *** 此处传递的参数为全局参数，如果参数无变化，支付的时候可以不用传递 ***
        // 乐堂服务器用户ID（必须）
        map.put(LtsdkKey.LtJoyId, mLtUserId);
        // 乐堂服务器ID（必须）
        map.put(LtsdkKey.LtInstantId, "222");
        // 乐堂服务器别名（必须）
        map.put(LtsdkKey.LtInstantAlias, "天下归心1");

        // *** 下面的参数为可选参数，可以参考LtsdkKey文件中的KEY列表 ***
        // 乐堂定义的AppId（必须）
        map.put(LtsdkKey.LtAppId, "5");
        // 游戏名称（必须）
        map.put(LtsdkKey.AppName, "应用名称");
        // 游戏角色ID（必须）
        map.put(LtsdkKey.RoleId, mLtUserId);
        // 游戏角色名（必须）
        map.put(LtsdkKey.RoleName, "游戏角色名");
        // 游戏用户帮派（必须）
        map.put(LtsdkKey.RolePartyName, "无帮派");
        // 游戏角色等级（必须）
        map.put(LtsdkKey.RoleLevel, "1");
        // 游戏用户VIP等级（必须）
        map.put(LtsdkKey.RoleVipLevel, "1");

        return map;
    }

    /** 获取支付所需的信息 */
    private Map<String, String> getPayInfo()
    {
        Map<String, String> map = new HashMap<String, String>();
        // 乐堂定义的AppId（必须）
        map.put(LtsdkKey.LtAppId, "5");
        // 乐堂服务器ID（必须）
        map.put(LtsdkKey.LtInstantId, "222");
        // 乐堂服务器别名（必须）
        map.put(LtsdkKey.LtInstantAlias, "天下归心");
        // 乐堂服务器自定义的参数（必须）
        map.put(LtsdkKey.LtReserve, "元宝100");
        // 乐堂服务器用户ID（必须）
        map.put(LtsdkKey.LtJoyId, mLtUserId);

        // 游戏名称（必须）
        map.put(LtsdkKey.AppName, "应用名称");
        // 游戏角色ID（必须）
        map.put(LtsdkKey.RoleId, mLtUserId);
        // 游戏角色名（必须）
        map.put(LtsdkKey.RoleName, "游戏角色名");
        // 游戏角色等级（必须）
        map.put(LtsdkKey.RoleLevel, "1");
        // 游戏用户VIP等级（必须）
        map.put(LtsdkKey.RoleVipLevel, "1");
        // 游戏用户余额（必须）
        map.put(LtsdkKey.RoleBalance, "100元宝");
        // 游戏用户帮派（必须）
        map.put(LtsdkKey.RolePartyName, "无帮派");

        // 购买商品的乐堂商品ID（必须）
        // 注意：请找商务获取乐堂商品ID与渠道商品ID对照表
        // 个别渠道是通过渠道商品ID来确认支付，所以游戏内每个计费商品都需要有唯一的编号

        String ProductId = Ltsdk.getInstance().getConfig(mAppContext, "ProductId", "1");
        map.put(LtsdkKey.ProductId, ProductId);
        // map.put(LtsdkKey.ProductId, "0");
        // 所购商品名称（必须）
        map.put(LtsdkKey.ProductName, "商品名称");
        // 所购商品图标（必须）
        // 直接传递图片的文件名
        map.put(LtsdkKey.ProductIcon, "ltsdk_product_img_48x48");
        // 所购商品名描述（必须）
        map.put(LtsdkKey.ProductDescript, "商品描述");
        // 所购买商品金额数，单位：分（必须）
        map.put(LtsdkKey.MoneyAmount, "1");

        // 应用扩展信息1（可选）
        map.put(LtsdkKey.AppExt1, "备注1");
        // 应用扩展信息2（可选）
        map.put(LtsdkKey.AppExt2, "备注2");
        return map;
    }

    /** 获取配置<br>
     * getConfig(..)用来获取Ltsdk配置文件中的配置<br>
     * 配置文件位置：assets/ltsdk_res/config.txt<br> */
    private void configHandler()
    {
        // 是否使用乐盟登录（已启用，打包时会配置）
        String useJoymengLogin = Ltsdk.getInstance().getConfig(mAppContext, "lt_usejoymenglogin", "false");
        if ("true".equals(useJoymengLogin))
        {
            // 使用乐盟登录
        }
        else
        {
            // 调用登录接口
        }
        Log.d(TAG, "useJoymengLogin=" + useJoymengLogin);

        // 是否自动登录（已启用，打包时会配置）
        String platformAutoLogin = Ltsdk.getInstance().getConfig(mAppContext, "lt_platformautologin", "false");
        if ("true".equals(platformAutoLogin))
        {
            // 立刻调用登录接口
        }
        Log.d(TAG, "platformAutoLogin=" + platformAutoLogin);

        // 获取Logo图片资源ID（已启用，打包时会配置）
        String name = Ltsdk.getInstance().getConfig(mAppContext, "platform_logo_img", "");
        name = name.replaceFirst("(\\.png|\\.jpg|\\.bmp|\\.gif)$", "");
        int logoImgid = mActivity.getResources().getIdentifier(name, "drawable", mActivity.getPackageName());
        Log.d(TAG, "logoImgid=" + logoImgid);

        // 获取Logo背景颜色（已启用，打包时会配置）
        String bgcolor = Ltsdk.getInstance().getConfig(mAppContext, "platform_logo_bgcolor", "");
        bgcolor = bgcolor.substring(1);
        int logoBgcolor = (int) Long.parseLong(bgcolor, 16);
        Log.d(TAG, "logoBgcolor=" + logoBgcolor);

        // 获取Logo展示时间（已启用，打包时会配置）
        String showtime = Ltsdk.getInstance().getConfig(mAppContext, "platform_logo_showtime", "");
        int logoShowtime = Integer.parseInt(showtime);
        Log.d(TAG, "logoShowtime=" + logoShowtime);

        // 获得AppID（未启用，打包时不会配置）
        String appId = Ltsdk.getInstance().getConfig(mAppContext, "lt_appid", "");
        Log.d(TAG, "appId=" + appId);

        // 获得ChannelID（未启用，打包时不会配置）
        String channelId = Ltsdk.getInstance().getConfig(mAppContext, "lt_channelid", "");
        Log.d(TAG, "channelId=" + channelId);

    }

    /** 打印Log和Toast信息 */
    private void printLog(final String log, final String toast)
    {
        if (Thread.currentThread() != Looper.getMainLooper().getThread())
        {
            mActivity.runOnUiThread(new Runnable()
            {
                @Override
                public void run()
                {
                    printLog(log, toast);
                }
            });
            return;
        }
        if (log != null)
        {
            Log.d(TAG, log);
        }
        if (toast != null)
        {
            Toast.makeText(mActivity, toast, Toast.LENGTH_SHORT).show();
        }
    }

}
