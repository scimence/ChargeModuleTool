
package com.ltsdk.union.platform;

import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.view.KeyEvent;

import com.ltsdk.union.LtsdkKey;
import com.ltsdk.union.util.PropertyUtil;
import com.sdk.tysdk.TYFactory;
import com.sdk.tysdk.interfaces.UserLoginOutFinishCallBack;
import com.tygrm.sdk.bean.TYRLoginBean;
import com.tygrm.sdk.bean.TYRPayBean;
import com.tygrm.sdk.bean.TYRPayGameParams;
import com.tygrm.sdk.bean.TYRUploadInfo;
import com.tygrm.sdk.cb.ITYRBackCallBack;
import com.tygrm.sdk.cb.TYRSDKListener;
import com.tygrm.sdk.constan.TYRCode;
import com.tygrm.sdk.constan.UserUploadType;
import com.tygrm.sdk.core.TYRSDK;


/** LtsdkBase.java: ----- 2019-01-03 10:16:51 wangzhongyuan */
public class LtsdkBase extends BaseFunction
{
    String game_id = "";

    /* 初始化 */
    public void _Init()
    {
        game_id = PropertyUtil.getConfig(activity, "game_id", "");

        TYRSDK.getInstance().TYRInit(activity, new TYRSDKListener()
        {
            @Override
            public void onSwitchAccount(TYRLoginBean data)
            {
                // data 如果为null,则说明sdk调用了注销,此时游戏应该清空登录信息,并重新唤起登录
                // data 如果不为null,则说明sdk内部调用了注销,并重新登录成功,需返回游戏区服界面，重新登录认证，重新加载新用户对应的角色数据

                LtsdkBase.this.platformSwitchAccount();	// 通知游戏切换帐号
            }

            @Override
            public void onInitChange(int code, String msg)
            {
                switch (code)
                {
                    case TYRCode.CODE_INIT_SUCCESS:
                        LtsdkBase.this.initSuccess();	// 通知游戏初始化成功
                        break;

                    case TYRCode.CODE_INIT_FAIL:
                        LtsdkBase.this.initFail();		// 通知游戏初始化失败
                        break;
                }
            }

            @Override
            public void onLoginChange(int code, TYRLoginBean tyrLoginBean)
            {
                switch (code)
                {
                    case TYRCode.CODE_LOGIN_SUCCESS:
                        // 记录渠道登录参数信息
                        AddLoginParams("version", "2");
                        AddLoginParams("sdkVersion", "20180417");

                        AddLoginParams("cp_game_id", game_id);						// 游戏id
                        AddLoginParams("release_user_id", tyrLoginBean.getsID());	// 用户token
                        AddLoginParams("release_token", tyrLoginBean.getToken());	// token

                        LtsdkBase.this.Platform_loginSuccess();						// 渠道登录成功
                        break;

                    case TYRCode.CODE_LOGIN_FAIL:
                        // 注意:失败时 data 可能是 null
                        LtsdkBase.this.Platform_loginFail();				// 渠道登录失败
                        Tools.showText("渠道登录失败，" + "code:" + code + "  ErrorMsg:" + tyrLoginBean.getMsg());
                        break;
                }
            }

            @Override
            public void onPayResult(int code, TYRPayBean tyrPayBean)
            {
                // String s = "";
                // if (tyrPayBean != null)
                // {
                // s = tyrPayBean.getPayID() + "" + tyrPayBean.getMoney();
                // }
                switch (code)
                {
                    case TYRCode.CODE_PAY_SUCCESS:
                        LtsdkBase.this.paySuccess(); 	// 支付成功
                        break;

                    case TYRCode.CODE_PAY_FAIL:
                        LtsdkBase.this.payFail(); 		// 支付失败
                        Tools.showToast(activity, "支付失败" + ", resultMsg:" + tyrPayBean.getMsg());
                        break;

                    case TYRCode.CODE_PAY_CANCEL:
                        LtsdkBase.this.payCancel(); 	// 支付取消
                        break;

                    case TYRCode.CODE_PAY_UNKNOWN:
                        LtsdkBase.this.payFail(); 		// 支付失败
                        Tools.showToast(activity, "支付失败" + "未知错误");
                        break;
                }
            }

            @Override
            public void onLogout()
            {
                // SDK 主动登出触发该回调，游戏调用 logout()接口不会收到该回调
                // 用户登出回调（需要收到该回调需要返回游戏登录界面，并调用 login 接口，打开 SDK 登录界面）

                LtsdkBase.this.platformSwitchAccount();	// 通知游戏切换帐号
            }
        });
    }

    /* 渠道登录 */
    public void _PlatformLogin()
    {
        TYRSDK.getInstance().login();
    }

    /** 渠道登出逻辑 */
    public void _LoginOut()
    {
        TYRSDK.getInstance().setGameLogOut(null);
    }

    /* 渠道支付 */
    public void _PlatformPay()
    {
        SdkInfo info = new SdkInfo(this); 	// 获取sdk中的参数信息

        // 如果没有对应参数 ,应该传入空字符串或者写死某一值.不能传入null
        TYRPayGameParams params = new TYRPayGameParams();
        params.setRoleid(info.RoleId);              // 角色id
        params.setCporder_sn(LtOrderId);  			// 游戏生成的订单编号
        params.setAmount(info.MoneyAmount_Double);  // 购买物品的总价 单位为元
        params.setProduct_name(info.ProductName);   // 购买物品的名称
        params.setBuyNum(1);                    	// 购买的数量
        params.setCoinNum(info.Balance);            // 当前玩家身上拥有的游戏币数量
        params.setProduct_id(info.ProductId);       // 购买物品的id
        params.setProduct_des(info.ProductDescript);// 购买物品的描述
        params.setRoleLevel(info.RoleLevel);        // 玩家等级
        params.setRolename(info.RoleName);          // 玩家名字
        params.setServerId(info.ServerId);          // 服务器id
        params.setServerName(info.SeverName);       // 服务器名
        params.setVip(info.RoleVipLevel);           // 角色vip等级

        TYRSDK.getInstance().pay(params);
    }

    /** 渠道退出逻辑 */
	public void _Quit()
	{
        TYFactory.getTYApi().LogOut(activity, new UserLoginOutFinishCallBack()
        {
            @Override
            public Activity LoginOut()
            {
                LtsdkBase.this.quitSuccess(); 	// 退出成功
                return null;
            }
        });
	}

    public boolean onKeyDown(int keyCode, KeyEvent event)
    {
        Tools.showText("onKeyDown() " + ", keyCode：" + keyCode + ", event：" + event.toString());
        return TYRSDK.getInstance().onKeyDown(activity, keyCode, event, new ITYRBackCallBack()
        {
            @Override
            public void onChannelExcit()
            {
                // 当玩家点击确认退出
                // finish();
                LtsdkBase.this.quitSuccess(); 	// 退出成功
            }

            @Override
            public void onGameExcit()
            {
                LtsdkBase.this.quitCustom(); 	// 自定义退出
            }
        });
    }

    /** 显示悬浮框 */
    public void _ShowToolbar()
    {
//		GameCenterSDK.getInstance().onResume(activity);
    }

    /** 隐藏悬浮框 */
    public void _HideToolbar()
    {
//		GameCenterSDK.getInstance().onPause();
    }

    /** 暂停游戏 */
    public void _OnPause()
    {
        TYRSDK.getInstance().onPause(activity);
    }

    /** 继续游戏 */
    public void _OnResume()
    {
        _ShowToolbar();
        TYRSDK.getInstance().onResume(activity);
    }

    /** 停止运行 */
    public void _OnStop()
    {
        _HideToolbar();
        TYRSDK.getInstance().onStop(activity);
    }

    /** Destroy */
    public void _OnDestroy()
    {
        TYRSDK.getInstance().onDestroy(activity);
    }

    /** 开始 */
    public void onStart()
    {
        TYRSDK.getInstance().onStart(activity);
    }

    public void onRestart()
    {
        TYRSDK.getInstance().onRestart(activity);
    }

    public void onNewIntent(Intent intent)
    {
        TYRSDK.getInstance().onNewIntent(intent, activity);
    }

    /** activityResult */
    public void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        TYRSDK.getInstance().onActivityResult(requestCode, resultCode, data, activity);
    }

    public void onConfigurationChanged(Configuration newConfig)
    {
        TYRSDK.getInstance().onConfigurationChanged(newConfig, activity);
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults)
    {
        TYRSDK.getInstance().onRequestPermissionsResult(requestCode, permissions, grantResults, activity);
    }

    private UserUploadType toSceneType(String sceneType)
    {
        if (sceneType.equals(LtsdkKey.SCENETYPE_360.enterServer))
            return UserUploadType.JOIN_SERVER;
        else if (sceneType.equals(LtsdkKey.SCENETYPE_360.createRole))
            return UserUploadType.CREATE_ROLE;
        else if (sceneType.equals(LtsdkKey.SCENETYPE_360.levelUp))
            return UserUploadType.UPGRADE;
        else if (sceneType.equals(LtsdkKey.SCENETYPE_360.exitServer))
            return UserUploadType.EXIT;
        else if (sceneType.equals(LtsdkKey.SCENETYPE_360.selectServer))
            return UserUploadType.FACTION;
        else return UserUploadType.OTHER;
    }

    /** 渠道上传游戏角色信息 */
    public void _UploadUserInfo()
    {
        SdkInfo info = new SdkInfo(this); // 获取sdk中的参数信息

        TYRUploadInfo userInfo = new TYRUploadInfo();

        userInfo.setRoleid(info.RoleId);        // 角色id
        userInfo.setRolename(info.RoleName);    // 角色名称
        userInfo.setRolelevel(info.RoleLevel);  // 角色等级
        userInfo.setZoneid(info.ServerId);      // 区服id
        userInfo.setZonename(info.SeverName);   // 区服名
        userInfo.setBalance(info.Balance);      // 帐户余额
        userInfo.setVip(info.RoleVipLevel);     // vip等级
        userInfo.setPartyname(info.PartyName);	 // 帮派信息 如果没有帮派信息 则传入-->无帮派
        userInfo.setAttach("原始数据");         	 // cp传入android 端的所有数据 如果是json 应该转义

        userInfo.setType(toSceneType(info.SceneType));

        TYRSDK.getInstance().reportedRoleInfo(userInfo);
    }

    /** 渠道上传游戏角色信息示例 */
    public void _UploadExample()
    {
        Map<String, String> map = new HashMap<String, String>();

        map.put(LtsdkKey.LtInstantId, "8001");							// 服务器id
        map.put(LtsdkKey.RoleName, "角色名称");							// 角色名称
        map.put(LtsdkKey.RoleLevel, "1");								// 角色等级

        setCommon(map);		// 调用接口上传游戏数据信息
    }

}
