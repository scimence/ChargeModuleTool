﻿package com.ltsdk.union;

import com.ltsdk.union.platform.Tools;

import android.app.Activity;
import android.os.Bundle;

/**  
 * JumpActivity.java:跳转界面，跳转到指定的游戏入口Activity
 * -----
 * 2017-5-26 上午9:40:49
 * wangzhongyuan 
 */
public class JumpActivity extends Activity
{
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		Tools.showGameEntryActivity(this);		// 进入游戏入口
		finish();
	}
}
