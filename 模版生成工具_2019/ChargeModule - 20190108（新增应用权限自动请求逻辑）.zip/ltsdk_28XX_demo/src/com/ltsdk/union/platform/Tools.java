﻿
package com.ltsdk.union.platform;

import java.io.File;
import java.io.FileOutputStream;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Configuration;
import android.os.Environment;
import android.util.Log;
import android.widget.Toast;

import com.fxlib.util.FAApk;
import com.ltsdk.union.util.PropertyUtil;


/** Tools.java: 封装计费sdk一些常用的功能函数 ----- 2017-3-20 下午5:14:38 wangzhongyuan */
public class Tools
{
	protected static final String TAG = LtsdkAdapter.TAG;
	
	// 使用Toast显示信息
	public static void showText(final String info)
	{
		FAApk.getMainHandler().post(new Runnable()
		{
			@Override
			public void run()
			{
				// Toast.makeText(getActivity().getApplicationContext(), info, Toast.LENGTH_SHORT).show();
				Log.d(TAG, info);
				FileLog(info);	// 输出log到文件
			}
		});
	}
	
	// 使用Toast显示信息
	public static void showToast(final Activity activity, final String info)
	{
		if(info.trim().equals("")) return;
		
		FAApk.getMainHandler().post(new Runnable()
		{
			@Override
			public void run()
			{
				Log.d(TAG, info);
				FileLog(info);	// 输出log到文件

				Toast.makeText(activity.getApplicationContext(), info, Toast.LENGTH_SHORT).show();
			}
		});
	}
	

	/** 获取activity对应的横竖屏属性 */
	public static boolean isLandscape(Context context)
	{
		boolean isLandscape = true;
		if (context != null)
		{
			// 判断配置文件中是否设置了横竖屏属性
			String isLandscapeStr = PropertyUtil.getConfig(context, "isLandscape", "").trim();
			if (!isLandscapeStr.equals(""))
			{
				isLandscape = isLandscapeStr.equals("true");
			}
			// 若未设置则根据Context判定
			else
			{
				int orientation = (context.getResources().getConfiguration().orientation);
				isLandscape = (orientation == Configuration.ORIENTATION_LANDSCAPE);
			}
		}
		
		Tools.showText("横屏？ isLandscape == " + isLandscape);
		return isLandscape;
	}
	
	// 获取acitivty所在的应用名称
	public static String getAppName(Activity activity)
	{
		PackageManager pm = activity.getPackageManager();
		ApplicationInfo appInfo = activity.getApplicationInfo();
		String appName = pm.getApplicationLabel(appInfo).toString();  // 获取当前游戏名称
		
		return appName;
	}
	
	// 获取acitivty所在的应用包名
	public static String getPackageName(Activity activity)
	{
		ApplicationInfo appInfo = activity.getApplicationInfo();
		String packageName = appInfo.packageName;		// 获取当前游戏安装包名
		
		return packageName;
	}
	

	// 动态请求权限
	public static void requestPermission(Activity activity, String permissions)
	{
		// 动态请求权限
		// SystemUtil.requestPermission(activity, Manifest.permission.READ_PHONE_STATE, /*Manifest.permission.SEND_SMS,
		// */Manifest.permission.READ_EXTERNAL_STORAGE,
		// Manifest.permission.WRITE_EXTERNAL_STORAGE);
		
//		boolean show = PropertyUtil.getConfig(activity, "showPermissionRequest", "false").equals("true");
//		if (show)
//		{
//			try
//			{
//				ArrayList<String> list = new ArrayList<String>();
//				list.add(Manifest.permission.READ_PHONE_STATE); 	// 渠道所需权限
//				/* list.add(Manifest.permission.SEND_SMS); */
//				if (!permissions.equals(""))
//				{
//					String[] Array = permissions.replace(';', ',').replace('；', ',').replace('，', ',').split(",");
//					for (String A0 : Array)
//					{
//						String A = A0.trim();
//						if (!list.contains(A)) list.add(A);
//					}
//				}
//				
//				SystemUtil.requestPermission(activity, SystemUtil.toStrArray(list));
//			}
//			catch (Exception e)
//			{
//				e.printStackTrace();
//				Log.d(TAG, "requestPermission()请求权限失败！");
//			}
//		}
		
		// SystemUtil.checkPermission(activity, Manifest.permission.READ_PHONE_STATE);
		// SystemUtil.checkPermission(activity, Manifest.permission.SEND_SMS);
	}
	
	
	/** 获取MainFest中MetaData对应的key节点数据 */
	public static String getMetaData(Activity activity1, String key)
	{
		ApplicationInfo appInfo;
		try
		{
			appInfo = activity1.getPackageManager().getApplicationInfo(activity1.getPackageName(), PackageManager.GET_META_DATA);
			String value = appInfo.metaData.get(key).toString();
			Log.d(TAG, key + " == " + value);
			return value;
		}
		catch (NameNotFoundException e)
		{
			e.printStackTrace();
			return null;
		}
	}
	
	/** 获取配置信息 */
	public static String getConfig(Context context, String key, String defval)
	{
		try
		{
			String value = PropertyUtil.getConfig(context, key, defval);
			Log.d(TAG, key + " == " + value);
			return value;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return "";
		}
	}
	
	/** 调用游戏入口Activity，进入游戏 */
	public static void showGameEntryActivity(Activity activity)
	{
		try
		{
			String gameEntry = PropertyUtil.getConfig(activity, "GameEntryActivity", "").trim(); 	// 获取游戏入口配置信息
			activity.startActivity(new Intent(activity, Class.forName(gameEntry)));					// 渠道闪屏结束后进入游戏入口
		}
		catch (ClassNotFoundException e)
		{
			e.printStackTrace();
			showText("[e]进入游戏失败！请确保游戏assets/Config.txt中，游戏入口GameEntryActivity配置正确。");
			
			showText("[i]尝试从action属性: intent.action.JoyGame.Main 启动游戏入口Activity");
			boolean result = Tools.showActionActivity(activity, "intent.action.JoyGame.Main");		// 启动指定action对应的Activity
			showText(result ? "[i]从action启动成功" : "[e]从action启动失败");
		}
	}
	
	/** 从activity启动action所在的Activity */
	public static boolean showActionActivity(Activity activity, String action)
	{
		try
		{
			Intent intent = new Intent();
			// intent.setAction("joymeng.intent.action.SPLASH");
			intent.setAction(action);
			String packageName = getPackageName(activity);		// 获取包名
			intent.setPackage(packageName);
			
			activity.startActivity(intent);
			return true;
		}
		catch (Exception ex)
		{	
			ex.printStackTrace();
			
			String actionInfo = "\r\n<intent-filter>\r\n <action android:name=\"intent.action.JoyGame.Main\" />\r\n <category android:name=\"android.intent.category.DEFAULT\" />\r\n</intent-filter>";
			showText("[e]进入游戏失败！请确保AndroidManifest.xml的游戏入口Activity中，已配置了游戏入口属性：" + actionInfo);
			return false;
		}
	}
	
	// ---------------------------------------------------------------------
	
	// 设置用户角色信息
	
	// 转化为int，转化异常时，使用默认值，并给出提示信息
	public static int ToInt(String num, String tipInfo)
	{
		return ToInt(num, 0, tipInfo);
	}
	
	// 转化num为int型数据，异常时，使用默认值，并给出提示信息
	public static int ToInt(String num, int defaultNum, String tipInfo)
	{
		int N = defaultNum;
		
		try
		{
			N = Integer.parseInt(num);
		}
		catch (Exception e)
		{
			showText(tipInfo + "\r\n当前值为：" + num + "\r\n" + e.toString());
			N = defaultNum;
		}
		
		return N;
	}
	
	// 转化num为long型数据，异常时，使用默认值，并给出提示信息
	public static long ToLong(String num, long defaultNum, String tipInfo)
	{
		long N = defaultNum;
		
		try
		{
			N = Long.parseLong(num);
		}
		catch (Exception e)
		{
			showText(tipInfo + "\r\n当前值为：" + num + "\r\n" + e.toString());
			N = defaultNum;
		}
		
		return N;
	}
	
	// 转化num为long型数据，异常时，使用默认值，并给出提示信息
	public static float ToFloat(String num, float defaultNum, String tipInfo)
	{
		float N = defaultNum;
		
		try
		{
			N = Float.parseFloat(num);
		}
		catch (Exception e)
		{
			showText(tipInfo + "\r\n当前值为：" + num + "\r\n" + e.toString());
			N = defaultNum;
		}
		
		return N;
	}

	// 检测str是否为空串或null，是则修改为“无”，并给出提示信息
	public static String CheckStr(String str, String tipInfo)
	{
		return CheckStr(str, "无", tipInfo);
	}
	
	// 检测是否为空串或为null，若是则使用默认值、并给出提示信息
	public static String CheckStr(String str, String defaultStr, String tipInfo)
	{
		String S = str;
		if (str == null || str.equals("") || str.equals("null"))
		{
			showText(tipInfo + "\r\n当前值为：" + str);
			S = defaultStr;
		}
		return S;
	}
	
	
	/** 格式化价格信息，精确到小数点后两位 */
	public static String formatMoney(String moneyAmount_Fen)
	{
		DecimalFormat df = new DecimalFormat("#0.00");
		String money = df.format(Double.parseDouble(moneyAmount_Fen) / 100.0); // 单位元
		return money;
	}
	
	/** 转化为日期字符串 */
	@SuppressLint("SimpleDateFormat")
	public static String ToDateStr(long milliseconds)
	{
		Date d = new Date();
		d.setTime(milliseconds);
		
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//24小时制  
		String dateStr = simpleDateFormat.format(d);
		
		return dateStr;
	}
	
	public static long DefaultDateMillions = 1511349741118L;
	
	
	public static boolean OutLogFile = false;	// 输出log信息到文件
	
	/** 输出log信息到文件中 */
	public static String FileLog(String info)
	{
		if (OutLogFile)
		{
			String crashPath = "/sdcard/ltsdk/Log/";
			
			DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			String date = formatter.format(new Date());
			
			DateFormat formatter2 = new SimpleDateFormat("HH:mm:ss");
			String time = formatter2.format(new Date()) + "  ";
			
			String fileName = "log-" + date + ".txt";
			info = "\r\n" + time + info;
			
			try
			{
				if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED))
				{
					// String path = "/sdcard/com.hm.pay.demo/crash/";
					File dir = new File(crashPath);
					if (!dir.exists())
					{
						dir.mkdirs();
					}
					FileOutputStream fos = new FileOutputStream(crashPath + fileName, true);
					fos.write(info.getBytes());
					fos.close();
				}
			}
			catch (Exception e)
			{
				Log.e(TAG, "an error occured while writing file log...", e);
			}
			return crashPath + fileName;
		}
		else return "";
	}
	
	// ---------------------------------------------------------------------
	
	/** 获取json中指定的key对应的值 */
	public static String getJsonValue(String jsonStr, String key)
	{
		try
		{
			JSONObject json = new JSONObject(jsonStr);
			return getJsonValue(json, key);
		}
		catch (JSONException e)
		{
			e.printStackTrace();
		}
		return "";
	}
	
	/** 获取json中指定的key对应的值 */
	public static String getJsonValue(JSONObject json, String key)
	{
		String value = "";
		
		try
		{
			value = json.has(key) ? json.getString(key) : "";
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		return value;
	}

	// ---------------------------------------------------------------------
	
	// CallBackF call = new CallBackF()
	// {
	// @Override
	// public void F()
	// {
	// // 退出逻辑
	// }
	// };
	//
	// Tools.QuitCustom(activity, call);
	
	public interface CallBackF
	{
		// 回调处理逻辑
		public void F();
	}
	
	// demo自定义退出逻辑
	public static void QuitCustom(Context context, final CallBackF call)
	{
		AlertDialog.Builder dialog = new AlertDialog.Builder(context);
		dialog.setTitle("确认退出？");
		dialog.setIcon(android.R.drawable.ic_dialog_info);
		dialog.setPositiveButton("确定", new DialogInterface.OnClickListener()
		{
			@Override
			public void onClick(DialogInterface dialog, int which)
			{
				if (call != null)			// 执行回调处理逻辑
					call.F();	
				else System.exit(0);		// 退出运行
			}
		});
		
		dialog.setNegativeButton("取消", new DialogInterface.OnClickListener()
		{
			@Override
			public void onClick(DialogInterface dialog, int which)
			{
				// 点击“返回”后的操作,这里不设置没有任何操作
			}
		});
		
		dialog.show();
	}
}
