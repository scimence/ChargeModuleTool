﻿
package com.ltsdk.union.platform;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;

import android.app.Activity;
import android.os.Handler;

import com.fxlib.util.FAApk;
import com.fxlib.util.FJHttp;
import com.ltsdk.union.Ltsdk;
import com.ltsdk.union.LtsdkKey;
import com.ltsdk.union.common.DefaultCallback;
import com.ltsdk.union.platform.LtsdkAdapter;
import com.ltsdk.union.platform.Tools;
import com.ltsdk.union.util.PropertyUtil;


/** BaseFunction.java: 继承自LtsdkAdapter，实现一些通用功能逻辑----- 2017-5-9 下午4:07:41 wangzhongyuan */
public abstract class BaseFunction extends LtsdkAdapter
{
	public static String plat_type = "Base";
	private String SDKName = "LtsdkAdapter_" + plat_type;
	
	// *** 乐堂配置 ***
	public static String LTSDK_SERVER_NAME = "netuser.joymeng.com";
	
	public static String LTSDK_LOGIN_URL = "http://netuser.joymeng.com/user/platlogin";
	public static String LTSDK_ORDER_URL = "http://netuser.joymeng.com/order/allplat";
	public static String LTSDK_CALLBACK_URL = "http://netuser.joymeng.com/charge_sy185/notify";
	public static String LTSDK_RASSIGN_URL = "http://netuser.joymeng.com/charge_huawei/rassign";
	public static String LTSDK_UserInfo_URL = "http://netuser.joymeng.com/charge_lehihi/userInfo";
	
	/** 重置服务器名称相关的，URL地址信息 */
	public static void UpdateServerName(String serverName)
	{
		if (serverName != null && !serverName.equals(""))
		{
			LTSDK_SERVER_NAME = serverName;
			LTSDK_LOGIN_URL = "http://" + LTSDK_SERVER_NAME + "/user/platlogin";
			LTSDK_ORDER_URL = "http://" + LTSDK_SERVER_NAME + "/order/allplat";
			LTSDK_CALLBACK_URL = "http://" + LTSDK_SERVER_NAME + "/charge_" + plat_type + "/notify";
			LTSDK_RASSIGN_URL = "http://" + LTSDK_SERVER_NAME + "/charge_" + plat_type + "/rassign";
			LTSDK_UserInfo_URL = "http://" + LTSDK_SERVER_NAME + "/charge_" + plat_type + "/userInfo";
		}
	}
	
	public String LtUserId;										// 乐堂用户id
	public String LtOrderId = System.currentTimeMillis() + "";	// 乐堂订单号
	
	public String LtGoldName = "元宝";
	public String LtGoldRate;
	
	public Activity activity;
	
	private DefaultCallback initCallback;			// 初始化结果回调
	private DefaultCallback platformLoginCallback;	// 渠道登录回调
	private DefaultCallback ltLoginCallback;		// 乐堂登录回调
	private DefaultCallback payCallback;			// 支付回调
	private DefaultCallback quitCallback;			// 退出回调
	private DefaultCallback antiAddictCallback;		// 防沉迷查询反馈结果回调
	
	// private boolean AutoGetAppName = true; // 是否动态获取应用名称
	public boolean isLandscape = true; 				// 是否为横屏
	
	private String permissions = "";				// 游戏附加的请求权限
	private boolean uploadUserInfo_OnLogin = true;	// 是否在用户登录后，自动上传用户角色信息
	
	private boolean isInitSuccess;					// 是否初始化成功
	private boolean platformLoginSuccess = false;	// 渠道是否登录功
	
	private boolean ltuserIsLoginSuccess = false;	// 乐堂用户是否已登录功
	JSONObject ltUserJson = null;					// 乐堂用户登录成功信息
	
	boolean lt_usejoymenglogin = false;				// 是否使用乐堂游戏登录
	
	public String platformUserId; 	// 渠道用户id
	public String platformToken; 	// 渠道用户token
	
	// public String token = "";
	// String appid = "";
	
	// String userId;
	// String username;
	
	// -----------------------------------------------------------
	// 按渠道sdk具体接口类型重写以下接口逻辑
	
	/** 渠道sdk初始化逻辑 */
	public abstract void _Init();
	
	/** 渠道登录逻辑 */
	public abstract void _PlatformLogin();
	
	// /** 添加渠道登录时获取的参数，用于乐堂登录验证 */
	// public abstract void _AddLoginParams();
	
	// AddLoginParams("sessionid", token);
	
	/** 渠道登出逻辑 */
	public void _LoginOut()
	{}
	
	/** 渠道退出逻辑 */
	public void _Quit()
	{
		quitCustom();		// 调用自定义退出
		// quitSuccess();
	}

//	/** 渠道切换帐号逻辑 */
//	public void _SwitchAccount()
//	{
//		Tools.showToast(activity,"请在悬浮窗中调用切换！\r\n（海信渠道，暂不支持在游戏主动调用）");
//	}
	
	/** 渠道切换帐号逻辑 */
	public void _SwitchAccount()
	{
		if (switchNeedReLogin)
		{
			ltuserIsLoginSuccess = false;
			_LoginOut();
			_PlatformLogin();
		}
		else 
		{
			switchNeedReLogin = true;	// 仅忽略一次切换登录请求
			Ltsdk.getInstance().login();
		}
	}
	
	/** 解析乐堂用户登录时的返回信息 */
	public void _Analyse_LtuserLoginData(JSONObject userJson) throws Exception
	{
		// 解析渠道的用户信息
		// JSONObject platformData = userJson.getJSONObject("platform_data");
		// platformToken = Tools.getJsonValue(platformData, "platform_token");
	}
	
	/** 添加创建乐堂订单时，所需的参数 */
	public void _AddLtOrderParams()
	{
		// AddLtOrderParams("packageName", packageName);
	}
	
	/** 解析创建订单时服务器返回信息 */
	public void _AnalyseOrderData(JSONObject rjson) throws Exception
	{
		// // 乐堂产品ID和渠道产品ID对照表
		// JSONObject mProductIdList = rjson.getJSONObject("plat_data").getJSONObject("productIdList");
		// Tools.showText("mProductIdList:" + mProductIdList);
	}
	
	/** 渠道支付逻辑 */
	public abstract void _PlatformPay();
	
	/** 渠道上传游戏角色信息 */
	public void _UploadUserInfo()
	{
		// Map<String, String> sdkInfo = getLtsdkInfo();
		//
		// String serverId = Tools.CheckStr(sdkInfo.get(LtsdkKey.LtInstantId), "001", "LtInstantId:服务器id"); // 服务器id
		// String serverName = Tools.CheckStr(sdkInfo.get(LtsdkKey.LtInstantAlias), "LtInstantAlias:服务器名"); // 服务器名
		//
		// String roleId = Tools.CheckStr(sdkInfo.get(LtsdkKey.RoleId), "RoleId:角色Id"); // 角色Id
		//
		// // roleId = gameId + "," + sdkInfo.get(LtsdkKey.LtInstantId) + "," + mLtUserId + "," + roleId; // gameid, 服务器id, joyid,roleid
		// // Tools.showText("乐堂 " + SDKName + " uploadUserInfo(), RoleId:" + roleId);
		//
		// String roleName = Tools.CheckStr(sdkInfo.get(LtsdkKey.RoleName), "RoleName:角色名"); // 角色名
		// String level = Tools.CheckStr(sdkInfo.get(LtsdkKey.RoleLevel), "RoleLevel:角色等级"); // 角色等级
		// String roleCTime = Tools.CheckStr(sdkInfo.get(LtsdkKey.roleCTime), "0", "roleCTime:角色创建时间"); // 角色创建时间
		//
		// // serverName = sdkInfo.get(LtsdkKey.LtInstantId) + "_" + serverName; // serverid_servername形式传服务器名
		//
		// mCenter.submitRoleInfo(serverId, serverName, roleId, roleName, level, roleCTime);
	}
	
	/** 渠道上传游戏角色信息示例 */
	public void _UploadExample()
	{
		Map<String, String> map = new HashMap<String, String>();
		
		map.put(LtsdkKey.LtInstantId, "8001");							// 服务器id
		map.put(LtsdkKey.LtInstantAlias, "天下归心1");					// 服务器名
		
		map.put(LtsdkKey.RoleId, "角色Id");								// 角色id
		map.put(LtsdkKey.RoleName, "游戏角色名");							// 角色名
		map.put(LtsdkKey.RoleLevel, "1");								// 角色等级
		map.put(LtsdkKey.roleCTime, System.currentTimeMillis() + "");	// 角色创建时间
		// map.put(LtsdkKey.sceneType, LtsdkKey.SCENETYPE_360.enterServer);// 场景类型
		
		setCommon(map);		// 调用接口上传游戏数据信息
	}
	
	/** 显示悬浮框 */
	public void _ShowToolbar()
	{}
	
	/** 隐藏悬浮框 */
	public void _HideToolbar()
	{}
	
	/** 暂停游戏 */
	public void _OnPause()
	{}
	
	/** 继续游戏 */
	public void _OnResume()
	{
		_ShowToolbar();
	}
	
	/** 停止运行 */
	public void _OnStop()
	{
		_HideToolbar();
	}
	
	/** Destroy */
	public void _OnDestroy()
	{}
	
	/** 实名注册接口，调用实名注册界面 */
	public void _realNameRegister()
	{
		Tools.showText("调用，用户实名认证");
	}
	
	/** 调用渠道接口，查询用户是否成年 */
	public void _antiAddictionQuery()
	{
		// UserType_unknown();
		// UserType_immature();
		UserType_mature();
	}
	
	// -----------------------------------------------------------
	// 乐堂sdk消息通知接口
	
	/** 初始化成功 */
	public void initSuccess()
	{
		Tools.showText("init() ->>初始化成功");
		
		isInitSuccess = true;							// 初始化完成
		Tools.requestPermission(activity, permissions);	// 动态请求权限
		if (initCallback != null) initCallback.onCallback(DefaultCallback.SUCCESS, "初始化成功", null);
	}
	
	/** 初始化失败 */
	public void initFail()
	{
		if (!isInitSuccess && this.isDebug()) // 调试时，默认初始化完成
		{
			Tools.showText("Init() ->>初始化失败！" + "调试模式，默认初始化成功！");
			initSuccess();
		}
		else
		{
			isInitSuccess = false;
			Tools.showText("Init() ->>初始化失败！");
			if (initCallback != null) initCallback.onCallback(DefaultCallback.FAIL, "初始化失败", null);
			
			reInitOnDelay();	// 延时再次初始化
		}
	}
	
	long delayMillis = 3000;
	boolean isReInit = false;
	
	// 延时再次调用初始化
	private void reInitOnDelay()
	{
		if (isReInit) return;	// 若已经在延时再次初始化，则不处理
			
		isReInit = true;
		delayMillis += 3000;	// 随初始化失败次数，延时时间依次延长
		new Handler().postDelayed(new Runnable()
		{
			@Override
			public void run()
			{
				isReInit = false;
				init(initCallback);
			}
		}, delayMillis);
		
	}
	
	/** 渠道登录成功 */
	public void Platform_loginSuccess()
	{
		Tools.showText("渠道登录成功");
		platformLoginSuccess = true;	// 渠道登录成功
		_ShowToolbar();					// 显示悬浮框
		if (platformLoginCallback != null) platformLoginCallback.onCallback(DefaultCallback.SUCCESS, "渠道登录成功", null);
	}
	
	/** 渠道登录失败 */
	public void Platform_loginFail()
	{
		Tools.showText("渠道登录失败");
		platformLoginSuccess = false;	// 渠道登录失败
		_HideToolbar();		// 隐藏悬浮框
		if (platformLoginCallback != null) platformLoginCallback.onCallback(DefaultCallback.FAIL, "渠道登录失败", null);
	}
	
	/** 取消登录 */
	public void platform_loginCancel()
	{
		Tools.showText("取消登录");
		if (platformLoginCallback != null) platformLoginCallback.onCallback(DefaultCallback.CANCEL, "取消登录 - CANCEL", null);
	}
	
	// /** 渠道登录成功 */
	// public void ltLoginSuccess()
	// {
	// Tools.showText("登录成功");
	// if (ltLoginCallback != null) ltLoginCallback.onCallback(DefaultCallback.SUCCESS, "登录成功", null);
	// }
	
	/** 乐堂用户登录成功 */
	public void ltLoginSuccess()
	{
		Tools.showText("登录成功");
		if (ltLoginCallback != null) ltLoginCallback.onCallback(DefaultCallback.SUCCESS, "登录成功", ltUserJson);
	}
	
	/** 渠道登录失败 */
	public void ltLoginFail()
	{
		Tools.showText("登录失败");
		if (ltLoginCallback != null) ltLoginCallback.onCallback(DefaultCallback.FAIL, "登录失败 - FAIL", null);
	}

	/** 登出成功 */
	public void loginOutSuccess()
	{
		loginOutSuccess(true);	// 默认需要重新登录
	}
	
	/** 登出成功（若渠道登出时已调用了登录，则不需要再次登录）*/
	public void loginOutSuccess(boolean needReLogin)
	{
		// 账号 退出 游戏需要重启到 登录界面
		platformAccountSwitch("切换用户成功");			// 用户登出，通知游戏切换用户
		// logout(); // 登出
		Tools.showText("onLogout() ->> 切换用户");
		
		switchNeedReLogin = needReLogin;
		if (switchNeedReLogin)  ltuserIsLoginSuccess = false;
	}
	
	/** 支付成功 */
	public void paySuccess()
	{
		if (payCallback != null) payCallback.onCallback(DefaultCallback.PAY_SUCCESS, "支付成功", null);	// 成功
		Tools.showText("platformPay() ->>支付成功");
	}
	
	/** 支付失败 */
	public void payFail()
	{
		if (payCallback != null) payCallback.onCallback(DefaultCallback.PAY_FAIL, "支付失败", null);		// 失败
		Tools.showText("platformPay() ->>支付失败");
	}
	
	/** 支付取消 */
	public void payCancel()
	{
		if (payCallback != null) payCallback.onCallback(DefaultCallback.PAY_CANCEL, "支付取消", null);	// 取消
		Tools.showText("platformPay() ->>支付取消");
	}
	
	/** 退出成功 */
	public void quitCustom()
	{
		Tools.showText("自定义退出");
		if (quitCallback != null)
			quitCallback.onCallback(DefaultCallback.QUIT_CUSTOM, "自定义退出", null);
		else Tools.showText("quitCallback == null");
	}
	
	/** 退出成功 */
	public void quitSuccess()
	{
		Tools.showText("退出成功");
		if (quitCallback != null) quitCallback.onCallback(DefaultCallback.QUIT_SUCCESS, "退出成功", null);
		
		activity.finish();	// 结束activity
		System.exit(0);		// 退出运行
	}
	
	/** 取消退出 */
	public void quitCancel()
	{
		Tools.showText("取消退出");
		if (quitCallback != null) quitCallback.onCallback(DefaultCallback.QUIT_CANCEL, "取消退出", null);
	}
	
	/** 通知游戏渠道已切换帐号 */
	public void platformSwitchAccount()
	{
		platformSwitchAccount(true);	// 默认需要重新登录
	}
	
	public boolean switchNeedReLogin = true;
	
	/** 通知游戏渠道已切换帐号（若渠道切换时已调用了登录，则不需要再次登录） */
	public void platformSwitchAccount(boolean needReLogin)
	{
		Tools.showText("切换帐号");
		_OnResume();							// 继续游戏逻辑
		platformAccountSwitch("切换账户成功");	// 通知游戏切换帐号
		
		switchNeedReLogin = needReLogin;
		if (switchNeedReLogin) ltuserIsLoginSuccess = false;
		
	}
	
	/** 未知用户 */
	public void UserType_unknown()
	{
		Tools.showText("未知用户");
		if (antiAddictCallback != null) antiAddictCallback.onCallback(DefaultCallback.USERTYPE_UNKNOWN, "未知用户", null);
	}
	
	/** 未成年用户 */
	public void UserType_immature()
	{
		Tools.showText("未成年用户");
		if (antiAddictCallback != null) antiAddictCallback.onCallback(DefaultCallback.USERTYPE_IMMATURE, "未成年用户", null);
	}
	
	/** 成年用户 */
	public void UserType_mature()
	{
		Tools.showText("成年用户");
		if (antiAddictCallback != null) antiAddictCallback.onCallback(DefaultCallback.USERTYPE_MATURE, "成年用户", null);
	}
	
	// -----------------------------------------------------------
	// 乐堂sdk基础功能逻辑函数
	
	/** Ltsdk初始化 */
	@Override
	protected void init(DefaultCallback callback)
	{
		if (callback != null) initCallback = callback;
		
		activity = getActivity();					// 获取Activity

		boolean needChekSign = PropertyUtil.getConfig(activity, "CheckSign", "true").equals("true");
		if(needChekSign) SignTool.CheckSign(activity);              // 校验签名信息

        
		isLandscape = Tools.isLandscape(activity);	// 获取横竖屏属性
		
		plat_type = getAccessPlatform();			// 获取当前的渠道类型信息
		SDKName = "SDK_" + plat_type;				// 设置log标签信息
		Tools.OutLogFile = PropertyUtil.getConfig(activity, "OutLogFile", "false").equals("true");	// 输出log信息到文件
		
		// if (!this.isDebug()) packageName = Tools.getPackageName(activity); // 获取当前的应用包名
		
		// 获取配置参数
		// APPKEY = PropertyUtil.getConfig(activity, "APPKEY", APPKEY).trim(); // 渠道参数APPKEY
		// APPSECRET = PropertyUtil.getConfig(activity, "APPSECRET", APPSECRET).trim(); // 渠道参数APPSECRET
		// md5key = PropertyUtil.getConfig(activity, "md5key", md5key).trim(); // 海信分配的支付md5key
		// gameId = PropertyUtil.getConfig(activity, "gameId", gameId).trim(); // 获取gameId
		// appid = Tools.getMetaData(activity, "80SY_APPID"); // 获取SDK平台的游戏ID
		
		// ltPayServerName=netuser.joymeng.com
		String serverName = PropertyUtil.getConfig(activity, "LtsdkServerName", LTSDK_SERVER_NAME).trim(); 	// 获取乐堂服务器名称
		UpdateServerName(serverName);			// 重置服务器地址信息
		
		LTSDK_CALLBACK_URL = PropertyUtil.getConfig(activity, "notifyUrl", LTSDK_CALLBACK_URL).trim(); 		// 若单独配置了回调地址，则设置为对应的地址
		Tools.showText("支付回调地址：" + LTSDK_CALLBACK_URL);
		
		permissions = PropertyUtil.getConfig(activity, "permissions", "").trim();							// 获取游戏的附加请求权限
		uploadUserInfo_OnLogin = PropertyUtil.getConfig(activity, "uploadUserInfo_OnLogin", "false").trim().equals("true");
		
		lt_usejoymenglogin = PropertyUtil.getConfig(activity, "lt_usejoymenglogin", "config.txt中未配置publicKey").trim().equals("true");	// 登录成功后，是否自动上传游戏角色信息
		
		// 初始化渠道sdk
		FAApk.getMainHandler().post(new Runnable()
		{
			@Override
			public void run()
			{
				Tools.showText("init()");
				_Init();	 				// 调用渠道登录
			}
		});
	}
	
	/** 渠道登录 */
	@Override
	protected void platformLogin(final DefaultCallback callback)
	{
		if (callback != null) platformLoginCallback = callback;
		
		if (isInitSuccess)
		{
			if (lt_usejoymenglogin)
			{
				Tools.showToast(activity, "当前设置为：lt_usejoymenglogin=true \n请使用游戏登录");
				return;
			}
			
			FAApk.getMainHandler().post(new Runnable()
			{
				@Override
				public void run()
				{
					Tools.showText("platformLogin()");
					
					if (ltuserIsLoginSuccess)
						ltLoginSuccess();	// 如果已登录，则直接返回游戏登录成功信息，不再调用渠道登录接口
					else _PlatformLogin();	 					// 调用渠道登录
				}
			});
		}
		else if (platformLoginCallback != null)
		{
			platformLoginCallback.onCallback(DefaultCallback.FAIL, "登录失败 - 未初始化 ", null);
			// init(initCallback); // 再次调用初始化
		}
	}
	
	HashMap<String, Object> platformParams = new HashMap<String, Object>();	// 记录渠道的参数信息
	
	/** 添加乐堂登录参数，传渠道相关参数至乐堂计费服务器 */
	public void AddLoginParams(String key, Object value)
	{
		platformParams.put(key, value);
	}
	
	/** 乐堂登录 */
	@Override
	protected void ltuserLogin(final DefaultCallback callback)
	{
		if (callback != null) ltLoginCallback = callback;
		
		if (!platformLoginSuccess)
		{
			callback.onCallback(DefaultCallback.FAIL, "请先登录", null);
			return;
		}
		
		try
		{
			// 向游戏服务器传递身份验证参数信息
			JSONObject platData = new JSONObject();
			platData.put("version", "1"); 					// 定值，与后台匹配
			
			// 添加渠道参数信息
			for (String param : platformParams.keySet())
			{
				Object value = platformParams.get(param);
				platData.put(param, value);
			}
			
			// platData.put("sessionid", token); // 渠道登录返回信息，sessionid
			// platData.put("appid", appid); // SDK平台的游戏ID
			// platData.put("userId", userId);
			// platData.put("username", username);
			// platData.put("sdkUserID", sdkUserId);
			// platData.put("sdkUsername", sdkUsername);
			
			// 从游戏服务器获取反馈信息
			HashMap<String, String> request = new HashMap<String, String>();
			request.put("app_id", getLtAppId());
			request.put("channel_id", getLtChannelId());
			// request.put("uuid", FADevice.getUUID(getAppContext()));
			request.put("uuid", Ltsdk.getInstance().getUuid());
			request.put("plat_type", getAccessPlatform());
			request.put("plat_data", platData.toString());
			
			String userData = FJHttp.request(LTSDK_LOGIN_URL, request, "post");
			Tools.showText("ltuserLogin() ->> request:" + request.toString());	// 乐堂登录请求信息
			Tools.showText("ltuserLogin() ->> userData:" + userData);			// 请求返回信息
			Tools.showText("登录请求 ->> " + LTSDK_LOGIN_URL + "?" + FJHttp.praseMap(request, FJHttp.DEFAULT_CHARSET));	// 请求参数信息
			
			JSONObject userJson = new JSONObject(userData);
			_Analyse_LtuserLoginData(userJson);					// 解析乐堂用户登录返回信息
			int status = userJson.getInt("status");
			switch (status)
			{
				case 1:		// 登录成功
					JSONObject contentJson = userJson.getJSONObject("content");
					
					// 乐堂用户ID
					LtUserId = contentJson.getString("uid");
					
					// 渠道的用户信息
					JSONObject platformData = userJson.getJSONObject("platform_data");
					platformUserId = platformData.getString("platform_uid");
					platformToken = Tools.getJsonValue(platformData, "platform_token");
					userJson.remove("platform_data");
					
					Tools.showText("乐堂用户ID: " + LtUserId);
					Tools.showText(SDKName + "用户ID: " + platformUserId);
					Tools.showText(SDKName + "Token: " + platformToken);
					
					ltuserIsLoginSuccess = true;		// 记录登录成功状态
					ltUserJson = userJson;				// 记录登录成功信息
					
					callback.onCallback(DefaultCallback.SUCCESS, "登录成功", userJson);
					if (uploadUserInfo_OnLogin) uploadUserInfo();	// 在用户登录成功后，自动提交用户角色信息
					break;
				
				default:	// 登录失败
					callback.onCallback(DefaultCallback.FAIL, "ltuserLogin - 登录失败", null);
					Tools.showToast(activity, "ltuserLogin - 登录失败" + " -> " + userData);
					break;
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
			callback.onCallback(DefaultCallback.FAIL, "登录失败，Exception: " + e.getMessage(), null);
			Tools.showToast(activity, "ltuserLogin - 登录失败，Exception: " + e.getMessage());
		}
	}
	
	protected void logout(final DefaultCallback callback)
	{
		Tools.showText("logout()");
		FAApk.getMainHandler().post(new Runnable()
		{
			@Override
			public void run()
			{
				_LoginOut();	// 调用渠道登出逻辑
				
				if (callback != null) callback.onCallback(DefaultCallback.SUCCESS, "注销成功", null);
				ltuserIsLoginSuccess = false;
			}
		});
	}
	
	protected void quit(final DefaultCallback callback)
	{
		if (callback != null) quitCallback = callback;
		
		Tools.showText("quit()");
		FAApk.getMainHandler().post(new Runnable()
		{
			@Override
			public void run()
			{
				_Quit();		// 调用渠道退出接口
			}
		});
	}
	
	public void onBackPressed()
	{
		// quit(quitCallback);
		quit();
	}
	
	/** 切换帐号 */
	@Override
	public void switchAccount()
	{
		LtUserId = null;
		
		FAApk.getMainHandler().post(new Runnable()
		{
			@Override
			public void run()
			{
				_SwitchAccount();			// 调用渠道切换帐号逻辑
			}
		});
		
		// isSwitchAccount = true;
		// this.login();
	}
	
	HashMap<String, Object> ltOrderParams = new HashMap<String, Object>();	// 记录渠道的参数信息
	
	/** 添加乐堂订单参数，传渠道相关参数至乐堂计费服务器，获取乐堂订单号 */
	public void AddLtOrderParams(String key, Object value)
	{
		ltOrderParams.put(key, value);
	}
	
	long preOrderTime = System.currentTimeMillis();	// 记录前一次创建订单的时间
	boolean LtOrderIdIsUsing = false;				// 当前乐堂订单号是否正在使用中
	
	/** 创建乐堂订单 */
	@Override
	protected void createLtOrder(DefaultCallback callback)
	{
		try
		{
			// 连续创建订单屏蔽：
			// （若距前一次请求时间小于2秒
			// （若未超过5s,且订单号正在使用中）
			// 超过5秒允许再次创建订单
			long currentTime = System.currentTimeMillis();
			long interval = currentTime - preOrderTime;
			if (interval < 2000 || (interval < 5000 && LtOrderIdIsUsing))
			{
				if (LtOrderIdIsUsing)
					Tools.showText("支付中，屏蔽连续创建订单");
				else Tools.showText("创建订单中，屏蔽连续创建订单");
				
				return;	 // 连续创建订单，自动屏蔽
			}
			else
			{
				preOrderTime = currentTime;		// 记录当前创建订单时间
				LtOrderIdIsUsing = false;
			}
			
			if (lt_usejoymenglogin)	// 获取游戏登录后的乐堂用户id
			{
				LtUserId = getLtsdkInfo().get(LtsdkKey.LtJoyId);
			}
			
			if (LtUserId == null)
			{
				if (this.isDebug())
					platformPay(null);
				else if (callback != null) callback.onCallback(DefaultCallback.FAIL, "乐堂用户Id为空，请先登录！", null);
				return;
			}
			
			_AddLtOrderParams();	// 添加创建乐堂订单时，所需的参数
			
			// 生成请求数据
			JSONObject platData = new JSONObject();
			platData.put("version", "1"); 					// 固定值，与服务器值对应
			// platData.put("packageName", packageName); // 包名信息，传送至服务器生成支付签名串
			
			// 添加渠道参数信息
			for (String param : ltOrderParams.keySet())
			{
				Object value = ltOrderParams.get(param);
				platData.put(param, value);
			}
			
			HashMap<String, String> request = new HashMap<String, String>();
			request.put("userid", LtUserId);
			request.put("appId", this.getLtAppId());
			request.put("instantid", getLtsdkInfo().get(LtsdkKey.LtInstantId));
			request.put("reserve", getLtsdkInfo().get(LtsdkKey.LtReserve));
			request.put("plat_type", getAccessPlatform());
			request.put("plat_data", platData.toString());
			String rdata = FJHttp.request(LTSDK_ORDER_URL, request, "post");
			
			Tools.showText("createLtOrder() ->> request:" + request.toString());	// 创建订单请求信息
			Tools.showText("createLtOrder() ->> rdata:" + rdata);					// 请求返回值
			Tools.showText("创建订单请求 ->> " + LTSDK_ORDER_URL + "?" + FJHttp.praseMap(request, FJHttp.DEFAULT_CHARSET));	// 请求参数信息
			
			JSONObject rjson = new JSONObject(rdata);	// {"plat_data":{"package_name_sign":"415f31906d472c36ad60e8425f2fabbf"},"orderId":"1368016","gold_rate":"10","gold_name":"元宝"}
			LtOrderId = rjson.getString("orderId");
			LtGoldName = rjson.getString("gold_name");
			LtGoldRate = rjson.getString("gold_rate");
			
			_AnalyseOrderData(rjson);	// 解析渠道其他参数信息
			
			// 本地生成支付签名串
			// paymentMD5Key = MD5Signature.md5(packageName + md5key); // com.ltgaem.cs.hisenseBAF212000C967971EA393A46EB490A06 ->
			// 415f31906d472c36ad60e8425f2fabbf
			// paymentMD5Key = rjson.getJSONObject("plat_data").getString("package_name_sign");
			
			Tools.showText("OrderId: " + LtOrderId);
			Tools.showText("gold_name(商品单位): " + LtGoldName);
			Tools.showText("gold_rate(兑换比例): " + LtGoldRate);
			
			if (LtOrderId != null && LtOrderId.length() > 0)
			{
				LtOrderIdIsUsing = true;
				callback.onCallback(DefaultCallback.SUCCESS, "订单创建成功", null);
			}
			else
			{
				callback.onCallback(DefaultCallback.FAIL, "订单创建失败, orderid=0", null);
				Tools.showToast(activity, "订单创建失败，" + " -> " + rdata);
			}
		}
		catch (Exception e)
		{
			callback.onCallback(DefaultCallback.FAIL, "订单创建失败，Exception: " + e.getMessage(), null);
			Tools.showToast(activity, "订单创建失败，Exception: " + e.getMessage());
		}
	}
	
	/** 渠道支付 */
	@Override
	protected void platformPay(final DefaultCallback callback)
	{
		if (callback != null) payCallback = callback;
		
		if ((LtUserId == null || LtUserId.equals("")) && !this.isDebug())
		{
			if (callback != null) callback.onCallback(DefaultCallback.PAY_FAIL, "请重新登录", null);
			return;
		}
		
		FAApk.getMainHandler().post(new Runnable()
		{
			@Override
			public void run()
			{
				try
				{
					// 调用支付接口
					Tools.showText("platformPay()");
					_PlatformPay();						// 调用渠道支付逻辑
					
					LtOrderIdIsUsing = false;			// 乐堂订单号已使用完毕
					LtOrderId = "";						// 清空当前订单信息
				}
				catch (Exception e)
				{
					e.printStackTrace();
					Tools.showText("乐堂 " + SDKName + " 支付异常！");
				}
			}
		});
	}
	
	/** 设置全局配置 */
	public void setCommon(Map<String, String> common)
	{
		super.setCommon(common);
		uploadUserInfo();
	}
	
	/** 上传游戏角色信息 */
	private void uploadUserInfo()
	{
		Tools.showText("uploadUserInfo() - 上传游戏角色信息");
		if ((LtUserId == null || LtUserId.equals("")) && !this.isDebug()) return;	// 若用户信息为空，则不执行
			
		try
		{
			FAApk.getMainHandler().post(new Runnable()
			{
				@Override
				public void run()
				{
					_UploadUserInfo();		// 上传用户角色信息
					
					Tools.showText("uploadUserInfo() ->> 上传游戏角色信息完成!");
					// Tools.showText("提交游戏角色信息：" + info.toString());
				}
			});
		}
		catch (Exception ex)
		{
			Tools.showText("上传游戏角色信息异常：" + ex.toString());
		}
	}
	
	/** 拓展接口， 上传用户角色信息示例 */
	protected void extension(String action, String json, DefaultCallback callback)
	{
		super.extension(action, json, callback);
		Tools.showText("extension()->" + " action:" + action + ", json:" + json);
		
		if (action.equals("UploadExample"))	// 上传用户角色信息示例
		{
			Tools.showText("_UploadExample()");
			_UploadExample();
		}
	}
	
	/** 显示工具条 */
	public void showToolbar()
	{
		Tools.showText("showToolbar()");
		FAApk.getMainHandler().post(new Runnable()
		{
			@Override
			public void run()
			{
				_ShowToolbar();
			}
		});
	}
	
	/** 关闭工具条 */
	public void hideToolbar()
	{
		Tools.showText("hideToolbar()");
		FAApk.getMainHandler().post(new Runnable()
		{
			@Override
			public void run()
			{
				_HideToolbar();
			}
		});
	}
	
	/** 重新开始 */
	public void onResume(Activity act)
	{
		Tools.showText("onResume()");
		FAApk.getMainHandler().post(new Runnable()
		{
			@Override
			public void run()
			{
				_OnResume();
			}
		});
	}
	
	/** 暂停 */
	public void onPause()
	{
		Tools.showText("onPause()");
		FAApk.getMainHandler().post(new Runnable()
		{
			@Override
			public void run()
			{
				_OnPause();
			}
		});
	}
	
	/** 停止 */
	public void onStop()
	{
		Tools.showText("onStop()");
		FAApk.getMainHandler().post(new Runnable()
		{
			@Override
			public void run()
			{
				_OnStop();
			}
		});
	}
	
	/** 销毁 */
	@Override
	public void onDestroy()
	{
		// Tools.showText("BaseFunction.onDestroy()");
		
		// FAApk.getMainHandler().post(new Runnable()
		// {
		// @Override
		// public void run()
		// {
		// _OnDestroy();
		// }
		// });
		
		Tools.showText("onDestroy()");
		_OnDestroy();
		
		super.onDestroy();
	}
	
	/** 实名注册逻辑 */
	@Override
	public void realNameRegister()
	{
		Tools.showText("realNameRegister()");
		FAApk.getMainHandler().post(new Runnable()
		{
			@Override
			public void run()
			{
				_realNameRegister();
			}
		});
	}
	
	/** 用户是否成年查询 */
	public void antiAddictionQuery(final DefaultCallback defaultCallback)
	{
		if (defaultCallback != null) antiAddictCallback = defaultCallback;
		
		Tools.showText("antiAddictionQuery()");
		FAApk.getMainHandler().post(new Runnable()
		{
			@Override
			public void run()
			{
				_antiAddictionQuery();
			}
		});
	}
	
}
