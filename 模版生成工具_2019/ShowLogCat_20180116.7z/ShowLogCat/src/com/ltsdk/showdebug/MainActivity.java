﻿
package com.ltsdk.showdebug;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.Menu;
import android.view.View;
import android.widget.Toast;

import com.ltsdk.tool.showtext.R;


public class MainActivity extends Activity
{
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	// 显示log信息
	public void OpenLog(View view)
	{
		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		String date = formatter.format(new Date());
		String fileName = "log-" + date + ".txt";
		
		OpenDir("/sdcard/ltsdk/Log/" + fileName);
	}
	
	// 显示异常信息信息
	public void OpenCrash(View view)
	{
		OpenDir("/sdcard/ltsdk/crash/");
	}
	
	private void OpenDir(String path)
	{
		try
		{
			if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED))
			{
				File file = new File(path);
				// Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
				
				Intent intent = new Intent();
				intent.setAction("android.intent.action.VIEW");
//				intent.setData(Uri.fromFile(file));  
				intent.setDataAndType(Uri.fromFile(file), "file/*.txt");
				
				intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				intent.setClassName("com.android.browser","com.android.browser.BrowserActivity");
				
//				
//				intent.addCategory(Intent.CATEGORY_DEFAULT);
//				intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//				intent.setDataAndType(Uri.fromFile(file), "file/*");
//				
//				intent.setClassName("com.android.browser", "com.android.browser.BrowserActivity");
				
				// intent.setDataAndType(Uri.fromFile(file), "*/*");
				// intent.addCategory(Intent.CATEGORY_OPENABLE);
				startActivity(intent);
			}
		}
		catch (Exception ex)
		{
			Toast.makeText(this, "文件路径" + path + "打开异常！", Toast.LENGTH_SHORT).show();
		}
	}
}
